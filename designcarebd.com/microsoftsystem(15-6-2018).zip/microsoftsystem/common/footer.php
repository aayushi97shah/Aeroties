 <script src="assets/js/jquery.min.js"></script>
    
    <!-- bootstrap js-->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- Mixitup js -->
    <script src="assets/js/jquery.mixitup.js"></script>

    <!-- plugin js -->
    <script src="assets/js/plugin.js"></script>

        <!-- Owl Carousel js -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Magnific popup js -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!-- Ajax Mailchimp js -->
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>

    <!-- Main js-->
    <script src="assets/js/jquery.meanmenu.js"></script>
    <script src="assets/js/main_script.js"></script>
    <script src="assets/js/myjs.js"></script>