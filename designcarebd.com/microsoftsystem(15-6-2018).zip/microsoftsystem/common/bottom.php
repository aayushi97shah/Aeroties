<!--footer top area start -->
    <section id="footer-top" class="footer-top-area section-big">
        <div class="container">
            <div class="row">
                
                <!-- Footer Widget -->
               <!--  <div class="col-md-3">
                    <div class="footer-top">
                       <div class="ft-logo">
                            <img src="assets/img/logo1.png" alt="">
                       </div>
                        <p>Claritas est etiam proc essus  quise quitur mutationem consue tudlecte Mirum est notare quam littera hum nita sdecima Eodem modo typi .</p>                      
                        <div class="subcriber-box">
                        
                            <form id="mc-form" class="mc-form">
                                <div class="newsletter-form">
                                    <input type="email" autocomplete="off" id="mc-email" placeholder="Your email" class="form-control">
                                    <button class="mc-submit" type="submit">
                                        <i class="fa fa-location-arrow"></i>
                                    </button> 
                                    <div class="clearfix"></div>
                                    <!-- mailchimp-alerts Start -->
                                    <!--<div class="mailchimp-alerts">
                                        <div class="mailchimp-submitting"></div>
                                        <!-- mailchimp-submitting end -->
                                       <!-- <div class="mailchimp-success"></div>
                                        <!-- mailchimp-success end -->
                                       <!-- <div class="mailchimp-error"></div>
                                        <!-- mailchimp-error end -->
                                   <!--  </div>
 -->                                    <!-- mailchimp-alerts end -->
                              <!--   </div>
                            </form>
                            
                        </div>
                    </div>
                </div> --> 
                
                <!-- Footer Widget -->
                <div class="col-md-4">
                    <div class="footer-top info">
                        <h3>Contact Us</h3>
                        
                        <div class="s-contact">                            
                            <p><i class="fa fa-phone"></i> <a href="tel:9825023045">+91 (98250)23045</a></p>
                        </div>
                        
                        <div class="s-contact"> 
                            <p><i class="fa fa-map-marker"></i>97,ShantiTower Near ManekbaugHal </p><p style="margin-left: 2.5rem;">Ahmedabad-380015</p>
                        </div>
                        
                        <div class="s-contact">
                            <p><i class="fa fa-envelope"></i>d786shah@yahooo.co.uk</p>
                        </div>
                        
                    </div>
                </div>
                
                <!-- Footer Widget -->
                <div class="col-md-4">
                    <div class="widget footer-top quick-menu">
                        <h3>Information</h3>
                        <ul class="q-link">
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="project.php">Product</a></li>
                            <li><a href="#">Application</a></li>
                            
                        </ul>
                    </div>
                </div>
                
                <!-- Footer Widget -->
               <!--  <div class="col-md-4">
                    <div class="footer-top fliker-list clearfix">
                        <h3>Instagram</h3>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-01.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                           <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-02.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                            <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-03.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                             <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-04.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                             <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-05.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                            <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-06.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                             <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-07.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                            <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-08.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                            <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="s-fliker">
                            <div class="f-img">
                                <img src="assets/img/footer-top/f-09.jpg" alt="">
                            </div>
                            <div class="f-img-overlay">
                                <div class="f-table">
                                    <div class="f-cell">
                                        <div class="fio-icon">
                                             <a href="#"><i class="fa fa-link"></i></a> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div> -->

            </div>
        </div>
    </section>
    <!--footer top area end -->

    
    <!-- copyright area start -->
    <footer id="footer" class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <div class="footer-text">
                        <p>All Rights Reserved &copy; Designed By themecare </p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="social pull-right">
                        <ul class="social-links">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div>
                <!-- <a class="smooth_scroll" href="#slider" id="scroll-to-top"><i class="fa fa-long-arrow-up"></i></a> -->
            </div>
        </div>
    </footer>
    <!-- copyright area end 