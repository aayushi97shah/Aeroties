<?php
// The message
$message = "good morning";

// In case any of our lines are larger than 70 characters, we should use wordwrap()
$to="aayushi97shah@gmail.com";
$Subject='My Subject';
$message = wordwrap($message, 70, "\r\n");
$headers =  'MIME-Version: 1.0' . "\r\n"; 
$headers .= "From:aayushi7shah@gmail.com";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
// Send
mail($to, $Subject,$message,$headers);
echo "test";
?>