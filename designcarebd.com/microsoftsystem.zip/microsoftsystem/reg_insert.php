<?php require 'connection.php';
if(!isset($_POST['submit']))
	{
		$username=$_POST['username'];
		$password=$_POST['password'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$name=$_POST['name'];
		$sql="INSERT INTO signup(username,password,email,phone,name)VALUES('".$username."','".$password."','".$email."',$phone,'".$name."')";
		$rs=mysqli_query($conn,$sql);
		if($rs){
			header("location:login.php");
		}
	}
		

?>
