<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from designcarebd.com/corvance/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:06:07 GMT -->
<head>
<?php require'common/header.php'?>
    
</head>

<body>

    <!-- Preloader starts -->
    <div id="preloader"></div>
    <!-- Preloader ends -->
    
    
   

   
   
   <?php require'common/top.php'?>



    <!-- Page Title area starts -->
    <section class="page-title section-big text-center">
        <div class="container">
            <h2>ABOUT US</h2>
            <p><a href="index-2.html">Home</a> <i class="fa fa-angle-double-right"></i> About Us</p>
        </div>
    </section>
    <!-- Page Title area ends -->

    

    <!-- about-area start -->
    <section id="about" class="about-area section-big clearfix">
        <div class="container">
                
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    <h2 class="subtitle">ABOUT US</h2>
                    <p>Dharmesh Shah, Director of Microsoft system has done B.E. PLASTIC TECH. In 1994.
                    After getting field experience in plastic proceesing & Service industries, by his 
                    Business tycoon nature has started MICROSOFT SYSTEM the PLASTIC PROCESSING UNIT,
                    Our unit Microsoft system is established in 1997, which manufacturing Plastics components,
                    for Various industrial applications.</p>
                    <p>Our product AEROTIES have versatile field applications, from aviation to packaging.
                    We develop its customised application as per our client requirements, by printing of
                    NAME - SERIAL NO.- LOGO-TRADE NAME Etc.</p>
                    <p>We are manufacturing Aeroties the pull tight security seals used for antipilferage
                    application for RETAIL MALL TO BULK DRUGS-DYES- CHEMICALS-FOOD-VEGETABLES PACKING.  
                    Our intermediate Size Aeroties are used by GARMENT INDUSTRIES & FMCG PACKING.</p>
                </div>

               

                
            </div>             
            
           <!--  <div class="space-80 hidden-xs clearfix"></div>
            <div class="space-50 visible-xs clearfix"></div>
 -->
            		       

        </div>       
    </section>
    <!-- About area ends -->

        

  
    
    <!-- Video area starts -->
    


    
    <?php require 'common/bottom.php'?>

        
         
    <!-- Latest jQuery -->

    <?php require 'common/footer.php'?>    
    
</body>


<!-- Mirrored from designcarebd.com/corvance/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:06:25 GMT -->
</html>