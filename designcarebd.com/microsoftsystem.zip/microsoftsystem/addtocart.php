<?php
session_start();
if(isset($_SESSION['cart']) & !empty($_SESSION['cart'])){
$items = $_SESSION['cart'];
$cartitems = explode(",", $items);
$items .= "," . $_GET['id'];

$_SESSION['cart'] = $items;
header('location: buynow.php?status=success');
}else{
$qty=$_POST['qty'];
$items = $_GET['id'];
$_SESSION['cart'] = $items;
echo $qty;
//echo $_SESSION['cart'];

header('location: buynow.php?status=success');
}

?>
