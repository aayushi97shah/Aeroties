<?php
require 'connection.php';

?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from designcarebd.com/corvance/project.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:06:54 GMT -->
<head>

    <!-- meta -->
    <?php require 'common/header.php' ?>
    
    
</head>

<body>

    <!-- Preloader starts -->
    <div id="preloader"></div>
    <!-- Preloader ends -->
    
    
    <!-- Top Bar Starts -->
   <!--Top Bar Starts -->
    <div class="header-top-area">
         <div class="container">
             <div class="row">
                 <div class="col-md-8 col-sm-10">
                     <div class="top-info-left">
                         <ul>
                             <li><a href="#">Call us :+(91)9825023045</a></li>
                             <li><a href="#">Email : d786shah@yahoo.co.uk</a></li>
                             
                         </ul>
                     </div>
                 </div>
                
             </div>
         </div>
    </div>
    <!-- Top Bar Ends -->

   


   
    <!-- Navigation area starts -->
    <div class="menu-area navbar-fixed-top">
        <div class="container">
            <div class="row">
            
                <!-- Navigation starts -->
                <div class="col-md-3 col-sm-3">
                    <div class="logo">
                        <a href="index.php"><img src="assets/img/logo1.png" alt=""></a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9 hidden-xs">
                    <div class="mainmenu">
                        <ul>
                            <li>
                                <a href="index.php">Home</a>
                                <!-- <ul class="sub-menu">
                                    <li><a href="index-2.html">Home 01</a></li>
                                    <li><a href="index2.html">Home 02</a></li>
                                    <li><a href="404.html">404 Page</a></li>
                                </ul> -->
                            </li>
                            <li><a href="about.php">About us</a></li>
                            
                            <li>
                                <a href="project.php">Product</a>
                                
                            </li>
                            <li>
                                <a href="application.php">Application</a>
                                
                            </li>
                            <li><a href="contact.php">Contact us</a></li>
                            <li><a href="login.php">BuyNow</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Navigation ends -->

                <div class="mobile-menu-area">
                    <div class="mobile-menu navbar-fixed-top">
                        <ul>
                            <li>
                                <a href="index.php">Home</a>
                               <!--  <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About us</a></li>
                                    <li><a href="product.php">Product</a></li>
                                    <li><a href="#">Application</a></li>
                                </ul> -->
                            </li>
                            <li><a href="about.php">About us</a></li>
                           
                            <li>
                                <a href="product.php">Product</a>
                                
                            </li>
                            <li>
                                <a href="applicatiion.php">Application</a>

                            </li>
                            <li><a href="contact.php">Contact us</a></li>
                             <li><a href="login.php">BuyNow</a></li>
                        </ul>
                    </div>
                </div>

            </div><!-- .row -->

            <div class="right-column hidden-xs">
                <div class="right-area">
                    <div class="nav_side_content">
                         <div id="display">

                      <a href="cart.php"> <i class="fa fa-shopping-cart" aria-hidden="true"></i></a> 

                   </div>
               </div>
                </div>                    
            </div> 


         </div><!-- .container -->
    </div>
    <!-- Navigation area ends-->
    <!-- Top Bar Ends -->
<?php
session_start();
$items=$_SESSION['cart'];
$cartitems=explode(",", $items);
?>

<br>
<br>
<br>
<section id="about" class="about-area clearfix">
        <div class="container-fluid">
            <div class="row d-flex">
            <table border="1" style="margin-left:50px; margin-bottom: 20px;">
            <tr>
		          <th>S.no</th>
		          <th>Item Name</th>
		          <th>Remove</th>
		          <th>Price</th>
                 
	       </tr> 



                <?php
                    $total1 = '';
                    $i=1;
                    foreach ($cartitems as $key=>$id) {
                    $sql = "SELECT * FROM products WHERE id = $id";
                    $res=mysqli_query($conn, $sql);
                    $r = mysqli_fetch_assoc($res);
                ?>	  
            <tr>
                <td><?php echo $i; ?></td>

                <td><?php echo $r['title']; ?></td>
                <td><a href="delcart.php?remove=<?php echo $key; ?>">Remove</a> </td>
                <td>$<?php echo $r['price']; ?></td>

            </tr>
            <?php
                $total1 = $total1 + $r['price'];
                $i++;
                $_SESSION['total']=$total1;
                $total=$_SESSION['total'];
                }
                ?>
            <tr>
                <td><strong>Total Price</strong></td>
                <td><strong>$<?php echo $total; ?></strong></td>
                <td colspan="2"><a href="checkout.php" class="btn btn-info">Checkout</a></td>
            </tr>
        </table>
</div>                 
        </div>       
    </section>

 

       <?php require 'common/bottom.php'?>
         
    <!-- Latest jQuery -->
   <?php require 'common/footer.php' ?>   
    
</body>


<!-- Mirrored from designcarebd.com/corvance/project.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:06:54 GMT -->
</html>

<!-- http://codingcyber.org/simple-shopping-cart-application-php-mysql-6394/ -->