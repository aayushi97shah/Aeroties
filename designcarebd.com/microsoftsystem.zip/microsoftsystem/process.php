<?php
require 'connection.php' ;
session_start();

		$name=$_POST['name'];
		$email=$_POST['email'];
		$address=$_POST['address'];
		$phone=$_POST['phone'];
		//echo $name;

		$qry="INSERT INTO customer(name,address,email,phone)VALUES('".$name."','".$address."','".$email."',$phone)";
		$rs=mysqli_query($conn,$qry);
		$customerid=mysqli_insert_id($conn);
		$date=date('Y-m-d');
		$qry1="INSERT INTO orders(date,customerid)VALUES('".$date."',$customerid)";
		$rs1=mysqli_query($conn,$qry1);
		/*if($rs1)
		{
			echo $customerid;
		}*/
		
		
		$max=count($_SESSION['cart']);

		echo $max;

		


?>
		
		