<?php
	require 'connection.php';
	session_start();
	var_dump($_POST);
	if(!isset($_POST['submit']))
	{
		header("location:login.php");
	}
	$username = $_POST['username'];
	$password = $_POST['password'];
	$qry = "SELECT * FROM signup WHERE username='".$username."' AND password='".$password."'";
	echo "$qry";
	$rs = mysqli_query($conn,$qry);
	if (mysqli_num_rows($rs) > 0)
	{
		$row = mysqli_fetch_assoc($rs);

		//echo $row['username'].$row['password'];
		//$_SESSION['username']=$row['username'];
		//$_SESSION['uid']=$row['fn_txt'];
		header("location:buynow.php");
	}
	else
	{
		header("location:login.php");
	}

?>