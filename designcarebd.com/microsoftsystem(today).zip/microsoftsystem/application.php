
<!--<?php //require 'common/header.php'?>-->
<!-- <?php //require 'common/top.php'?>

<?php //require 'common/footer.php'?>
<?php //require 'common/bottom.php' ?> -->

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from designcarebd.com/corvance/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:03:08 GMT -->
<head>

    <!-- meta -->
   <?php require 'common/header.php'; ?>
    
</head>

<body>

    <!-- Preloader starts -->
    <div id="preloader"></div>
    <!-- Preloader ends -->
    <?php require 'common/top.php';?>
    
    <!-- Slider area starts -->
   
    <!-- Slider area ends -->
    <br>
    <br>


    <!-- about-area start -->
    <section id="about" class="about-area clearfix">
        <div class="container-fluid">
            <div class="row d-flex">

                <!-- About Image -->
              <br>

                <!-- About Text -->
                <div class="col-md-12 col-xs-12">

                    <div class="about-text clearfix">

                        <div class="section-title">
                            
                            <h2>Fundamental Work</h2>
                        </div>
                       <div class="">We are known in the industry as producers of various industrial products. However, our fundamental<br>
            (or specific) work profile includes following tasks:
            <div style="margin-left: 20px;">
              <ul style="list-style: circle;color: black">
                <li>We design &amp; manufacture plastic mouldings for different applications namely cableties,security seals used for different
                field applications </li>
                <li>We develop security seals as per customised requirements. </li>
                <li>Application of our security seals for export packing of pharmaceutical chemicals,dyestuffs,pigments,etc.</li>
                
              </ul>
            </div>
          </div>

            </div>			       
        </div>       
    </section><!-- About area ends -->

        

  
                </div>


            </div><!-- .row -->

            
        </div>
    </section>
     <?php require 'common/bottom.php'?>

        
         
    <!-- Latest jQuery -->

    <?php require 'common/footer.php'?>  
                
	
</body>


<!-- Mirrored from designcarebd.com/corvance/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:04:20 GMT -->
</html>