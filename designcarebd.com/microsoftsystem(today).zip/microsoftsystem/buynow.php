<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from designcarebd.com/corvance/project.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:06:54 GMT -->
<head>

    <!-- meta -->
    <?php require 'common/header.php' ?>
    
    
</head>

<body>

    <!-- Preloader starts -->
    <div id="preloader"></div>
    <!-- Preloader ends -->
    
    
    <!-- Top Bar Starts -->
   <!--Top Bar Starts -->
    <div class="header-top-area">
         <div class="container">
             <div class="row">
                 <div class="col-md-8 col-sm-10">
                     <div class="top-info-left">
                         <ul>
                             <li><a href="#">Call us :+(91)9825023045</a></li>
                             <li><a href="#">Email : d786shah@yahoo.co.uk</a></li>
                             
                         </ul>
                     </div>
                 </div>
                
             </div>
         </div>
    </div>
    <!-- Top Bar Ends -->

   


   
    <!-- Navigation area starts -->
    <div class="menu-area navbar-fixed-top">
        <div class="container">
            <div class="row">
            
                <!-- Navigation starts -->
                <div class="col-md-3 col-sm-3">
                    <div class="logo">
                        <a href="index.php"><img src="assets/img/logo1.png" alt=""></a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9 hidden-xs">
                    <div class="mainmenu">
                        <ul>
                            <li>
                                <a href="index.php">Home</a>
                                <!-- <ul class="sub-menu">
                                    <li><a href="index-2.html">Home 01</a></li>
                                    <li><a href="index2.html">Home 02</a></li>
                                    <li><a href="404.html">404 Page</a></li>
                                </ul> -->
                            </li>
                            <li><a href="about.php">About us</a></li>
                            
                            <li>
                                <a href="project.php">Product</a>
                                
                            </li>
                            <li>
                                <a href="application.php">Application</a>
                                
                            </li>
                            <li><a href="contact.php">Contact us</a></li>
                            <li><a href="buynow.php">BuyNow</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Navigation ends -->

                <div class="mobile-menu-area">
                    <div class="mobile-menu navbar-fixed-top">
                        <ul>
                            <li>
                                <a href="index.php">Home</a>
                               <!--  <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About us</a></li>
                                    <li><a href="product.php">Product</a></li>
                                    <li><a href="#">Application</a></li>
                                </ul> -->
                            </li>
                            <li><a href="about.php">About us</a></li>
                           
                            <li>
                                <a href="product.php">Product</a>
                                
                            </li>
                            <li>
                                <a href="applicatiion.php">Application</a>

                            </li>
                            <li><a href="contact.php">Contact us</a></li>
                             <li><a href="buynow.php">BuyNow</a></li>
                        </ul>
                    </div>
                </div>

            </div><!-- .row -->

            <div class="right-column hidden-xs">
                <div class="right-area">
                    <div class="nav_side_content">
                         <div id="display">

                      <a href="cart.php"> <i class="fa fa-shopping-cart" aria-hidden="true"></i></a> 

                   </div>
               </div>
                </div>                    
            </div> 


         </div><!-- .container -->
    </div>
    <!-- Navigation area ends-->
    <!-- Top Bar Ends -->
    

   


   
   
   
            
                
               



    <!-- Page Title area starts -->
    <section class="page-title section-big text-center">
        <div class="container">
            <h2>LATEST PROJECT</h2>
            <p><a href="index.php">Home</a> <i class="fa fa-angle-double-right"></i> Cable ties And Security Seals</p>
        </div>
    </section>
    <!-- Page Title area ends -->
    


    <!-- Work area starts -->
    <section id="work" class="works section-big">
        <div class="container">

            <div class="row">

                <!-- Works filter -->
                <ul class="work filters">
                    <li class="filter" data-filter="all">CableTies & Security Seals</li>
                  
                   
                </ul>
                <!-- / Works filter -->

            </div>
            <?php
            require 'connection.php';
    $sql = "SELECT * FROM products";
$res = mysqli_query($conn,$sql);
?>
<?php while($r = mysqli_fetch_assoc($res)){ ?>

            <div class="portfolio">
                <div class="row work-items">

                    <!-- work item -->
                    <div class="col-md-4 col-sm-12 col-xs-12 mix illustrate web brand">
                        <div class="item">
                            <img src="<?php echo $r['image']; ?>" alt="" height=20%>
                            <span class="cat"><?php echo $r['title'] ?></span>
                            <div class="overlay">
                                <div class="icon">
                                    <p><?php echo $r['description'] ?></p>
                                    <p><?php echo $r['price']?></p>
                                     <p><a href="addtocart.php?id=<?php echo $r['id']; ?>" class="btn btn-primary" role="button";>Add to Cart</a></p>
                                      <p><a href="login.php?id=<?php echo $r['id']; ?>" class="btn btn-primary" role="button";>BuyNow</a></p>
                                    <!-- <a href="#">Add to cart</a>
                                    <a href="login.php">BuyNow</a> -->
                                    <!-- <p class="tag">Finance, Insurance</p> -->
                                    <!-- <a href="ass" class="work-popup"><i class="fa fa-eye"></i></a> -->
                                </div>
                               <!--  <a href="#"><i class="fa fa-long-arrow-right"></i></a> -->
                            </div>
                        </div>
                    </div>

                    <?php } ?>

                    <!-- work item -->
                   

                    

                </div>
            </div>

        </div>
    </section>
    <!-- Work area ends -->

        

    


    
   <?php require 'common/bottom.php'?>

        
         
    <!-- Latest jQuery -->
   <?php require 'common/footer.php' ?>   
    
</body>


<!-- Mirrored from designcarebd.com/corvance/project.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:06:54 GMT -->
</html>