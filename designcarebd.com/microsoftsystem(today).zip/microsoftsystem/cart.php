<?php
require 'connection.php';

?>

<table border="1">
	<tr>
		<th>S.no</th>
		<th>Item Name</th>
		<th>Price</th>
	</tr>
	<tr>
		<td>Item Number</td>
		<td><a href="delcart.php?remove=">Remove</a></td>
		<td>$1000</td>
	</tr>
	<tr>
		<td><strong>Total Price</strong></td>
		<td><strong>$1000</strong></td>
		<td><a href="#">checkout</a></td>
	</tr>
</table>
<?php
session_start();
$items=$_SESSION['cart'];
$cartitems=explode(",", $items);
?>
<!-- /*http://codingcyber.org/simple-shopping-cart-application-php-mysql-6394/*/ -->
<table border="1">
<tr>
		<th>S.no</th>
		<th>Item Name</th>
		<th>Remove</th>
		<th>Price</th>
	</tr> 



<?php
$total1 = '';
$i=1;
foreach ($cartitems as $key=>$id) {
$sql = "SELECT * FROM products WHERE id = $id";
$res=mysqli_query($conn, $sql);
$r = mysqli_fetch_assoc($res);
?>	  
<tr>
<td><?php echo $i; ?></td>

<td><?php echo $r['title']; ?></td>
<td><a href="delcart.php?remove=<?php echo $key; ?>">Remove</a> </td>
<td>$<?php echo $r['price']; ?></td>
</tr>
<?php
$total1 = $total1 + $r['price'];
$i++;
$_SESSION['total']=$total1;
$total=$_SESSION['total'];
}
?>
<tr>
<td><strong>Total Price</strong></td>
<td><strong>$<?php echo $total; ?></strong></td>
<td colspan="2"><a href="logout.php" class="btn btn-info">Checkout</a></td>
</tr>

<!-- http://codingcyber.org/simple-shopping-cart-application-php-mysql-6394/ -->