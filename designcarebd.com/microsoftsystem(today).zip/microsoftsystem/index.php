<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from designcarebd.com/corvance/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:03:08 GMT -->
<head>

    <!-- meta -->
   <?php require 'common/header.php'; ?>
    
</head>

<body>

    <!-- Preloader starts -->
    <div id="preloader"></div>
    <!-- Preloader ends -->
    
    
  

   


   
    <?php require 'common/top.php';?>
    
    <!-- Slider area starts -->
    <section id="slider">
        <div id="carousel-example-generic" class="carousel slide carousel-fade">
        
            <div class="carousel-inner" role="listbox">
                <!-- Item 1 -->
                <div class="item active slide1">
                    <div class="table">
                        <div class="table-cell">
                            <div class="intro-text">
                                <div class="container">
                                    <div class="title clearfix">
                                        <p>Welcome to Microsoft System</p>
                                        <h1> <span>Aeroties</span></h1>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>

                <!-- Item 2 -->
                <div class="item slide2">
                    <div class="table">
                        <div class="table-cell">
                            <div class="intro-text">
                                <div class="container">
                                    <div class="title clearfix">
                                        <p>Welcome to Microsoft System</p>
                                        <h1><span>Aeroties</span></h1>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Item 3 -->
                <div class="item slide3">
                    <div class="table">
                        <div class="table-cell">
                            <div class="intro-text">
                                <div class="container">
                                    <div class="title clearfix">
                                        <p>Welcome to Microsoft System</p>
                                        <h1><span>Aeroties-As a Pull Tigth Security Seals</span></h1>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Item 4 -->
                <div class="item slide4">
                    <div class="table">
                        <div class="table-cell">
                            <div class="intro-text">
                                <div class="container">
                                    <div class="title clearfix">
                                        <p>Welcome to Microsoft System</p>
                                        <h1><span>Plastic Drum Seals</span></h1>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <a class="left welcome-control" href="#carousel-example-generic" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                 <a class="right welcome-control" href="#carousel-example-generic" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>

            </div>
            <!-- End Wrapper for slides-->

             <!-- Carousel Pagination -->
            
            <div class="container hidden">
                <div class="row bullets-area">
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    </ol>
                </div>
            </div>

        </div>
    </section>
    <!-- Slider area ends -->
    

    <!-- about-area start -->
    <section id="about" class="about-area clearfix">
        <div class="container-fluid">
            <div class="row d-flex">

                <!-- About Image -->
               <div class="col-md-5 col-xs-12 about-bg">
                    <div class="about-title">
                        <div class="section-title white">
                            <span>information with</span>
                            <h2>ABOUT US</h2>
                        </div>
                        <P>Microsoft System is a prestigious firm which Manufacture and supplies, different Industrial Products. In our large product line we offer Cable Management Accessories..& security seals.</p>
                        <a class="btn" href="about.php">READ MORE</a>
                    </div>
                </div>

                <!-- About Text -->
                <div class="col-md-7 col-xs-12">

                    <div class="about-text clearfix">

                        <div class="section-title">
                            
                            <h2>Fundamental Work</h2>
                        </div>
                       <div class="">We are known in the industry as producers of various industrial products. However, our fundamental<br>
            (or specific) work profile includes following tasks:
            <div style="margin-left: 20px;">
              <ul style="list-style: circle;color: black">
                <li>We design &amp; manufacture plastic mouldings for different applications namely cableties,security seals used for different
                field applications </li>
                <li>We develop security seals as per customised requirements. </li>
                <li>Application of our security seals for export packing of pharmaceutical chemicals,dyestuffs,pigments,etc.</li>
                
              </ul>
            </div>
          </div>

            </div>			       
        </div>       
    </section><!-- About area ends -->

        

  
                </div>


            </div><!-- .row -->

            
        </div>
    </section>
     <?php require 'common/bottom.php'?>

        
         
    <!-- Latest jQuery -->

    <?php require 'common/footer.php'?>  
                
	
</body>


<!-- Mirrored from designcarebd.com/corvance/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 May 2018 09:04:20 GMT -->
</html>